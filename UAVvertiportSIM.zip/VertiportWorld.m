classdef VertiportWorld
    properties
        size_x
        size_y
        circle_radius
        landing_spots
        landing_space_obj
        figure_handle 
        num_waypoints
        waypoint_radius
        height 
        theta 
        waypoints 
        waypoint_handles 
        outer_square_size
        outer_square_x_offset
        outer_square_y_offset
        center_x
        center_y
        occupied = [false,false,false]
        queue 
        coordinates 
        occupancymat
        allPaths
        pointsPerSemiCircle
        nSemiCircles
        hoverHeight
        landingPads
        AZones = ones(4,1)
        COOPMOVE
    end
    
    methods
        function obj = VertiportWorld(Structure,size_x, size_y, circle_radius, landing_space_obj, outer_square_size, outer_square_x_offset, outer_square_y_offset, landing_spots)
            obj.size_x = size_x;
            obj.size_y = size_y;
            obj.circle_radius = circle_radius;
            obj.landing_space_obj = landing_space_obj;
            obj.outer_square_size = outer_square_size;
            obj.outer_square_x_offset = outer_square_x_offset;
            obj.outer_square_y_offset = outer_square_y_offset;

            if nargin < 8
                % Default landing spots if not provided
                    obj.landing_spots = [
                    size_x/3, size_y/2 - 20; % Spot 1
                    size_x/3, size_y/2;       % Spot 2
                    size_x/3, size_y/2 + 20   % Spot 3
                ];
            else
                obj.landing_spots = landing_spots;
            end
        
            % Define waypoint parameters
            obj.num_waypoints = 1;
            obj.waypoint_radius = 1; % Radius of waypoints' circular path
            obj.height = [15 15 15]; % Height of waypoints
            obj.theta = linspace(0, 2*pi, obj.num_waypoints + 1);
            obj.theta(end) = []; % Remove last value to avoid duplication

            % Create a new figure for plotting
            obj.figure_handle = figure;
            hold on;
            
            
            % Calculate the center based on the outer square's position
            obj.center_x = obj.outer_square_x_offset + obj.outer_square_size / 2;
            obj.center_y = obj.outer_square_y_offset + obj.outer_square_size / 2;
            
            
            plotWorld(obj);
            
            % Initialize waypoints and handles
            obj.waypoints = cell(size(obj.landing_spots,1), 1);
            obj.waypoint_handles = cell(size(obj.landing_spots,1), 1); % Store handles to update waypoints
            
            % Plot the initial waypoints
            hold on;
            for i = 1:size(obj.landing_spots,1)
                x_center = obj.landing_spots(i, 1) + (obj.center_x - obj.size_x/2);
                y_center = obj.landing_spots(i, 2) + (obj.center_y - obj.size_y/2);
                obj.waypoints{i} = [x_center + obj.waypoint_radius * -sin(obj.theta)', ...
                                    y_center + obj.waypoint_radius * -cos(obj.theta)'];
            end
            hold off;

            
             for t = 1 : size(obj.landing_spots,1)
            obj.landingPads(t,:) = [obj.waypoints{t}(1), obj.waypoints{t}(2), 0]; 
                        
             end
            
    if Structure == 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.nSemiCircles = 3;  % Number of semi-circles
            obj.pointsPerSemiCircle = [10, 6, 3];  % Points in each semi-circle
            obj.occupancymat = zeros(1,sum(obj.pointsPerSemiCircle)+ size(obj.landing_spots,1));
            radiusArray = [60, 45, 30];  % Radii for each semi-circle
            heightArray = [80, 47.5, 15];  % Heights for each semi-circle
            centrepoint = [90, 100];  % Center point for the semi-circles
            obj.hoverHeight = 8;                        % Height above the landing pad for hover

            % Define three landing pads in a line at the same z-coordinate
            for t = 1 : size(obj.landing_spots,1)
            obj.landingPads(t,:) = [obj.waypoints{t}(1), obj.waypoints{t}(2), 0]; 
                        
            end
            entryPoint = 6;                          % Index of entry point on outermost semi-circle

            % Call the function
            [obj] = generateLandingPaths(obj,obj.nSemiCircles, obj.pointsPerSemiCircle, radiusArray, heightArray, obj.landingPads, obj.hoverHeight, entryPoint,centrepoint);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    end
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %COOP funciton
        function [vertiport] = COOP(vertiport, assignedPaths)
            
            vertiport.COOPMOVE = assignedPaths;
          
        end
        
        %Assign zones for OM method
        function [vertiport] = az(vertiport,k)
            
            vertiport.AZones(k) = 1;
            
        end
        
        %add to occupancy matrix
        function [obj] = Findocc(obj,occ)
         
            obj.occupancymat(occ) = obj.occupancymat(occ) + 1; 
            
        end
        
        %Remove from occupancy matrix
        function [obj] = REMocc(obj,occ)
         
            obj.occupancymat(occ) = obj.occupancymat(occ) - 1; 
            
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        
function plotWorld(obj)
            % Plot the outer square boundary with custom position and size
            rectangle('Position', [obj.outer_square_x_offset, obj.outer_square_y_offset, obj.outer_square_size, obj.outer_square_size], ...
                      'EdgeColor', 'k', 'LineWidth', 2);
            hold on;
            
            % Plot the inner square vertiport (centered)
            rectangle('Position', [obj.center_x - obj.size_x/2, obj.center_y - obj.size_y/2, obj.size_x, obj.size_y], ...
                      'EdgeColor', 'b', 'LineWidth', 2);
            
            % Plot the Detection Circle
            theta0 = linspace(0, 2*pi, 100);
            x_circle = obj.circle_radius * cos(theta0) + obj.center_x;
            y_circle = obj.circle_radius * sin(theta0) + obj.center_y;
            plot(x_circle, y_circle, 'r--', 'LineWidth', 2);
            

            % Plot the landing spaces using the LandingSpace object
            for i = 1:size(obj.landing_spots, 1)
                x_offset = obj.landing_spots(i, 1) + (obj.center_x - obj.size_x/2);
                y_offset = obj.landing_spots(i, 2) + (obj.center_y - obj.size_y/2);
                obj.plotLandingSpaceAt(x_offset, y_offset);
            end
           
            
            
            % Set axis limits based on the new outer square boundary
            xlim([obj.outer_square_x_offset obj.outer_square_x_offset + obj.outer_square_size]);
            ylim([obj.outer_square_y_offset obj.outer_square_y_offset + obj.outer_square_size]);
            
            xlabel('X (meters)');
            ylabel('Y (meters)');
        end
        
    function [obj] = generateLandingPaths(obj,nSemiCircles, pointsPerSemiCircle, radiusArray, heightArray, landingPads, hoverHeight, ~,centrepoint)
 
    % Initialize storage for coordinates
    obj.coordinates = [];
    
    % Loop over each semi-circle to generate the points
    for i = 1:nSemiCircles
        % Current number of points, radius, and height
        nPoints = pointsPerSemiCircle(i);
        radius = radiusArray(i);
        height0 = heightArray(i);
        
        % Angles for the current semi-circle
        theta0 = linspace(0, pi, nPoints) + pi/2;
        
        % Generate x, y coordinates for the current semi-circle
        x = radius * cos(theta0) + centrepoint(1);
        y = radius * sin(theta0) + centrepoint(2);
        z = height0 * ones(1, nPoints);  % Set constant height for each semi-circle
        
        % Append the coordinates to the overall matrix
        obj.coordinates = [obj.coordinates; x', y', z'];  % Concatenate to the list of coordinates
    end
    
    % Add a hover point directly above each landing pad at the hover height
    hoverPads = [landingPads(:, 1:2), hoverHeight * ones(size(landingPads, 1), 1)];
    obj.coordinates = [obj.coordinates; hoverPads];
    
    % Append landing pads to the list of coordinates
    obj.coordinates = [obj.coordinates; landingPads];
    
    hold on;
    
    % Plot each semi-circle with a filled circle and curved line
    for i = 1:nSemiCircles
        idxStart = sum(pointsPerSemiCircle(1:i-1)) + 1;
        idxEnd = sum(pointsPerSemiCircle(1:i));
        
        % Plot the semi-circles with filled circles
        %fill3(obj.coordinates(idxStart:idxEnd, 1), obj.coordinates(idxStart:idxEnd, 2), obj.coordinates(idxStart:idxEnd, 3), 'b', 'FaceAlpha', 0.5, 'DisplayName', ['Semi-circle ' num2str(i)]);
        
        % Plot filled points
        scatter3(obj.coordinates(idxStart:idxEnd, 1), obj.coordinates(idxStart:idxEnd, 2), obj.coordinates(idxStart:idxEnd, 3), 15, 'filled');
        
        % Plot curved lines around each semi-circle
        theta0 = linspace(0, pi, 100) + pi/2;
        xCircle = radiusArray(i) * cos(theta0) + centrepoint(1);
        yCircle = radiusArray(i) * sin(theta0) + centrepoint(2);
        zCircle = heightArray(i) * ones(size(xCircle));  % Constant height
        plot3(xCircle, yCircle, zCircle, 'k-', 'LineWidth', 1.5);  % Curved line
    end
 end    
                   
    % Recursively explore all paths inward to the landing pads
    function [obj] = explorePaths(obj,currentPoint, currentPath, depth,pointsPerSemiCircle,landingPads, hoverHeight,nSemiCircles)
        
        
     % Add a hover point directly above each landing pad at the hover height
    hoverPads = [landingPads(:, 1:2), hoverHeight * ones(size(landingPads, 1), 1)];
    
    % Number of total points generated 
    nTotalPoints = sum(pointsPerSemiCircle);
    nHoverPoints = size(hoverPads, 1);  % Number of hover points
       
        
        
        if depth == nSemiCircles
            % At the innermost semi-circle, connect to the closest hover point
            hoverPadDistances = vecnorm(hoverPads(:, 1:2) - obj.coordinates(currentPoint, 1:2), 2, 2);
            [~, closestHoverIndex] = min(hoverPadDistances);
            currentPath = [currentPath, nTotalPoints + closestHoverIndex];  % Include closest hover pad index
            
            % Then, directly connect to the corresponding landing pad
            currentPath = [currentPath, nTotalPoints + nHoverPoints + closestHoverIndex];  % Include the landing pad
            obj.allPaths{end+1} = currentPath;  % Store the completed path
            return;
        end
        
        % Determine the number of points on the current and next semi-circles
        currentSemiCirclePoints = pointsPerSemiCircle(depth);
        nextSemiCirclePoints = pointsPerSemiCircle(depth + 1);
        
        % Compute the index ranges for the current and next semi-circle
        currentIndexStart = sum(pointsPerSemiCircle(1:depth-1)) + 1;
        currentIndexEnd = sum(pointsPerSemiCircle(1:depth));
        nextIndexStart = sum(pointsPerSemiCircle(1:depth)) + 1;
        nextIndexEnd = sum(pointsPerSemiCircle(1:depth + 1));
        
        % Get the coordinates for the current and next semi-circles
        currentCoords = obj.coordinates(currentIndexStart:currentIndexEnd, :);
        nextCoords = obj.coordinates(nextIndexStart:nextIndexEnd, :);
        
        % Ensure currentPoint is within bounds of the currentCoords array
        currentLocalIdx = currentPoint - currentIndexStart + 1;
        if currentLocalIdx > currentSemiCirclePoints || currentLocalIdx < 1
            return;  % Skip if index is out of bounds
        end
        
        % Find the two closest points in the next semi-circle from the current point
        distances = vecnorm(nextCoords - currentCoords(currentLocalIdx, :), 2, 2);
        [~, sortedIdx] = sort(distances);  % Sort the distances to get the closest points
        
        % Get the two closest points and recursively explore paths through them
        for k = 1:min(2, length(sortedIdx))  % Choose the two closest points
            closestPoint = sortedIdx(k);  % The index of the closest point in the next semi-circle
            [obj] = explorePaths(obj,closestPoint + nextIndexStart - 1, [currentPath, closestPoint + nextIndexStart - 1], depth + 1,pointsPerSemiCircle,landingPads, hoverHeight,nSemiCircles);
        end
    end
        

        function plotLandingSpaceAt(obj, x_offset, y_offset)
            hold on;
            
            % Plot and fill the circle in yellow at the offset position
            theta0 = linspace(0, 2*pi, 100);
            x_circle = obj.landing_space_obj.Radius * cos(theta0) + x_offset;
            y_circle = obj.landing_space_obj.Radius * sin(theta0) + y_offset;
            fill(x_circle, y_circle, 'yellow'); % Fill the circle with yellow
            plot(x_circle, y_circle, 'b', 'LineWidth', obj.landing_space_obj.LineWidth); % Outline in blue
            
            % Plot the H (with the yellow background inside the circle)
            plot([-obj.landing_space_obj.HWidth/2, -obj.landing_space_obj.HWidth/2] + x_offset, ...
                 [-obj.landing_space_obj.HHeight/2, obj.landing_space_obj.HHeight/2] + y_offset, ...
                 'b', 'LineWidth', obj.landing_space_obj.LineWidth);
            plot([obj.landing_space_obj.HWidth/2, obj.landing_space_obj.HWidth/2] + x_offset, ...
                 [-obj.landing_space_obj.HHeight/2, obj.landing_space_obj.HHeight/2] + y_offset, ...
                 'b', 'LineWidth', obj.landing_space_obj.LineWidth);
            plot([-obj.landing_space_obj.HWidth/2, obj.landing_space_obj.HWidth/2] + x_offset, ...
                 [0, 0] + y_offset, 'b', 'LineWidth', obj.landing_space_obj.LineWidth);
        end  
        
%      function [obj] = UpdateQ(obj, min1)
% 
%         obj.queue(min1) = obj.queue(min1) + 1; 
%      end
%      
    end
    
    
end
