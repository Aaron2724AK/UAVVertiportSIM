classdef Aircraft
    % ===============================================================
    % Class - Aircraft
    % This class contains all the properties of the Aircraft
    %
    % Methods: Protected
    %           [obj] = initProbability(obj, world)
    %           [obj] = initUncertainty(obj, world)
    %           [obj] = integrateVelocity(obj, cumulation, dt)
    %           [obj] = getAcceleration(obj, cumulation, dt)
    %           [obj] = integrateYaw(obj, cumulation, dt)
    %           [obj] = getYawRate(obj, cumulation, dt)
    %           [obj] = getYawAcceleration(obj, cumulation, dt)
    %           [obj] = integratePosition(obj, cumulation, dt)
    %           [obj] = updateUncertainty(obj, world, cumulation)
    %           [obj] = updateProbability(obj, targets, world, cumulation)
    %           [obj] = moveAgent(obj, world, cumulation, dt)
    %           [obj] = getMultirotorWaypoint(obj, world, unreachable_grids, grid_agent_yaw, cumulation)
    %           [obj] = getFixedwingWaypoint(obj, world, unreachable_grids, grid_agent_yaw, cumulation)
    %          Private
    %           [obj] = expandArrays(obj, world, iter)
    %
    % Created by: Zihao Wang
    % Last updated: 25-07-2018
    % Update by Aaron Koulouris 21/10/2024 line > 591 
    % ===============================================================
    properties
        % type
        % type 1 = fixed wing
        % type 2 = multirotor
        type
        
        % states
        x                       % x-position
        y                       % y-position
        z                       % z-position
        roll                    % roll angle
        pitch                   % pitch angle
        yaw                     % heading angle
        yaw_rate                % heading change rate
        yaw_acceleration        % heading acceleration
        velocity                % velocity
        acceleration            % acceleration
        distanceerror
        % fixed wing performance
        max_yawrate             % maximum yaw rate
        max_velocity            % maximum velocity
        min_velocity            % minimum velocity
        max_acceleration        % maximum acceleration
        max_yaw_acceleration    % maximum yaw acceleration

        % sensor properties
        camera_fov              % camera field of view
        camera_range            % distance covered by the camera

        % probability grid and maps
        prob_map                % target probability map
        prob_map_sum            % sum of target probability map
        uncert_map              % environment uncertainty map
        uncert_map_sum          % sum of environment uncertainty map
        sensor_map              % a logic map represents all tiles in the sensor range
        detect_map              % a logic map represents all tiles marked as target detected
        nodetect_map            % a logic map represents all tiles marked as target not detected

        % figure handles
        figure_handle_uncertainty   % aircraft figure handle for uncertainty map
        figure_handle_probability   % aircraft figure handle for probability map
        figure_handle_interests     % aircraft figure handle for interests map
        figure_handle_debug         % aircraft figure handle for debug
        figure_handle_waypoint      % waypoint plot handle
        uncertainty_map_handle      % uncertainty map handle
        probability_map_handle      % probability map handle
        
        % system dynamics
        velocity_setpoint           % velocity setpoint
        acceleration_setpoint       % acceleration setpoint
        yaw_setpoint                % yaw (heading) setpoint
        yaw_rate_setpoint           % yaw rate setpoint
        yaw_acceleration_setpoint   % yaw acceleration setpoint
        x_setpoint                  % position x setpoint
        y_setpoint                  % position y setpoint
        z_setpoint                  % position y setpoint
        % gains
        pos_p                       % position error to velocity setpoint gain
        vel_p                       % velocity error to acceleration setpoint gain
        yaw_p                       % heading error to yaw speed setpoint gain
        yaw_rate_p                  % yaw speed error to yaw acceleration setpoint gain
        yaw_acl_p                   % yaw acceleration error to yaw acceleration gain
        acl_p                       % acceleration error to acceleration gain
  
%       Properties for sequencing aircraft
        hasLanded = false          %Check if UAV has landed
        SPOTTED = false            %Is the UAV in the vertiport airspace
        foundIndex                 %Found Index for AQM 
        allPaths                   %Path array to store all avaiable paths for AQM
        CurrentP                   %Current UAV path
        freeSpotIndex = 0          % Current UAV spot index in occupancy matrix
        LocalQUE                   % Local queue index for current freeSpotIndex
        QN                         %Queue number
        PreviousQueueLocation      %Previous queue location
        index                      %Index for debug (Experimental)
        AZones                     %Assigned zones of OM method
        assignedLandingZone = 0    %Assigned landing zone parameter
        status                     %holding structure status
        COOP                       %Coop term for AQM
        remove                     %Paramter for removing UAV for occupancy matrix
        Movetime = 0               %Experiemntal move time
        Holdtime = 0               %Experimental Hold time
        reached = false            %Paramter for testing if correct z location for reached
        xprevspot                  %Previous x location for FCFS
        yprevspot                  %Previous y location for FCFS
        zprevspot                  %Previous z location for FCFS 
        x_new                      %New x location for FCFS
        y_new                      %New y location for FCFS
        z_new                      %New z location for FCFS
        rl = false                 %Parameter for testing if holding points was reached (FCFS)
    end

    methods
        % constructor
        function obj = Aircraft(type,x,y,z,roll,pitch,yaw,velocity,max_velocity,min_velocity,max_yawrate)
            if nargin > 0
                obj.type            = type;
                obj.x               = x;
                obj.y               = y;
                obj.z               = z;
                obj.roll            = roll;
                obj.pitch           = pitch;
                obj.yaw             = yaw;
                obj.velocity        = velocity;
                obj.max_velocity    = max_velocity;
                obj.min_velocity    = min_velocity;
                obj.max_yawrate     = max_yawrate;
                obj.foundIndex = -1;
                
            % assign default values if no values are given
            else
                obj.type            = 2;
                obj.x               = 0;
                obj.y               = 0;
                obj.z               = 0;
                obj.roll            = 0;
                obj.pitch           = 0;
                obj.yaw             = 0;
                obj.velocity        = 0;
                obj.max_velocity    = 10;
                obj.min_velocity    = 0;
                obj.max_yawrate     = deg2rad(45);
            end
            
            % no acceleration at initial condition
            obj.acceleration        = 0;
            obj.yaw_rate            = 0;
            obj.yaw_acceleration    = 0;
            
            % temp max acceleration
            obj.max_acceleration    = 5;
            % temp max yaw acceleration
            obj.max_yaw_acceleration= deg2rad(45);
            
            % fixed parameters
            obj.camera_fov          = deg2rad(120);
            obj.camera_range        = 200;
            
            % gains
            % fixed wing gains
            if obj.type == 1
                obj.pos_p       = 0.7;
                obj.vel_p       = 0.8;
                obj.yaw_p       = 0.5;
                obj.yaw_rate_p  = 0.5;
                obj.yaw_acl_p   = 0.5;
                obj.acl_p       = 0.3;
            % multirotor gains
            else
                obj.pos_p       = 0.7;
                obj.vel_p       = 0.8;
                obj.yaw_p       = 0.5;
                obj.yaw_rate_p  = 0.5;
                obj.yaw_acl_p   = 0.5;
                obj.acl_p       = 0.5;
            end
        end
        
        %% protected methods
        % ========================
        % initialise probability
        % ========================
        function [obj] = initProbability(obj, world)
            obj.prob_map            = ones(world.number_of_tiles_y, world.number_of_tiles_x).*world.prob0;
            obj.prob_map_sum        = sum(sum(obj.prob_map));
        end
        
        % ========================
        % initialise uncertainty
        % ========================
        function [obj] = initUncertainty(obj, world)
            obj.uncert_map          = ones(world.number_of_tiles_y, world.number_of_tiles_x).*world.uncert0;
            obj.uncert_map_sum      = sum(sum(obj.uncert_map));
        end
        
        % ========================
        % integrate velocity
        % ========================
        function [obj] = integrateVelocity(obj, cumulation, dt)
            % velocity error = setpoint - velocity
            velocity_error          = obj.velocity_setpoint(cumulation) - obj.velocity(cumulation-1);
            % acceleration setpoint = velocity gain * velocity error
            % limit acceleration setpoint according to direction
            if velocity_error >= 0
                obj.acceleration_setpoint(cumulation) = min(obj.max_acceleration, obj.vel_p*velocity_error);
            else
                obj.acceleration_setpoint(cumulation) = max(-obj.max_acceleration, obj.vel_p*velocity_error);
            end
            % get acceleration
            [obj]                   = getAcceleration(obj, cumulation, dt);
            delta_velocity          = obj.acceleration(cumulation)*dt;
            % integrate velocity
            obj.velocity(cumulation)= obj.velocity(cumulation-1)+delta_velocity;
        end
        
        % ========================
        % get acceleration
        % ========================
        function [obj] = getAcceleration(obj, cumulation, dt)
            % acceleration error = setpoint - acceleration
            acceleration_error      = obj.acceleration_setpoint(cumulation) - obj.acceleration(cumulation-1);
            % change in accleration = accleration gain * acceleration error * dt
            delta_acceleration      = obj.acl_p*acceleration_error*dt;
            % get acceleration
            obj.acceleration(cumulation) = obj.acceleration(cumulation) + delta_acceleration;
            % limit acceleration according to direction
            if obj.acceleration(cumulation) >= 0
                obj.acceleration(cumulation) = min(obj.max_acceleration, obj.acceleration(cumulation));
            else
                obj.acceleration(cumulation) = max(-obj.max_acceleration, obj.acceleration(cumulation));
            end
        end
        
        % ========================
        % integrate yaw (heading)
        % ========================
        function [obj] = integrateYaw(obj, cumulation, dt)
            % yaw error = yaw setpoint - current yaw
            yaw_error               = obj.yaw_setpoint(cumulation)-obj.yaw(cumulation-1);
            % normalise yaw error
            if yaw_error > pi
                yaw_error           = yaw_error - 2*pi;
            elseif yaw_error < -pi
                yaw_error           = yaw_error + 2*pi;
            end
            % yaw rate setpoint = yaw gain * yaw error
            % limit yaw rate to max yaw rate according to direction
            if yaw_error >= 0
                obj.yaw_rate_setpoint(cumulation) = min(obj.yaw_p*yaw_error,obj.max_yawrate);
            else
                obj.yaw_rate_setpoint(cumulation) = max(obj.yaw_p*yaw_error,-obj.max_yawrate);
            end
            % get yaw rate
            [obj]                   = getYawRate(obj, cumulation, dt);
            % integrate yaw
            delta_yaw               = obj.yaw_rate(cumulation) * dt;
            obj.yaw(cumulation)     = wrapTo2Pi(obj.yaw(cumulation-1)+delta_yaw);
        end
        
        % ========================
        % get yaw rate
        % ========================
        function [obj] = getYawRate(obj, cumulation, dt)
            % yaw rate error = yaw rate setpoint - current yaw rate
            yaw_rate_error          = obj.yaw_rate_setpoint(cumulation) - obj.yaw_rate(cumulation-1);
            % yaw acceleration setpoint = yaw rate gain * yaw rate error
            % limit yaw acceleration to max yaw acceleration according to direction
            if yaw_rate_error >= 0
                obj.yaw_acceleration_setpoint(cumulation) = min(obj.yaw_rate_p*yaw_rate_error, obj.max_yaw_acceleration);
            else
                obj.yaw_acceleration_setpoint(cumulation) = max(obj.yaw_rate_p*yaw_rate_error, -obj.max_yaw_acceleration);
            end
            % get yaw acceleration
            [obj]                   = getYawAcceleration(obj, cumulation, dt);
            % integrate yaw rate
            delta_yaw_rate          = obj.yaw_acceleration(cumulation) * dt;
            obj.yaw_rate(cumulation)= obj.yaw_rate(cumulation-1) + delta_yaw_rate;
        end
            
        % ========================
        % get yaw acceleration
        % ========================
        function [obj] = getYawAcceleration(obj, cumulation, dt)
            % yaw acceleration error = setpoint - yaw acceleration
            yaw_acceleration_error  = obj.yaw_acceleration_setpoint(cumulation) - obj.yaw_acceleration(cumulation-1);
            % change in yaw acceleration = yaw acceleration gain * yaw acceleration error * dt
            delta_yaw_acceleration  = obj.yaw_acl_p*yaw_acceleration_error*dt;
            % get yaw acceleration
            obj.yaw_acceleration(cumulation) = obj.yaw_acceleration(cumulation) + delta_yaw_acceleration;
            % limit yaw acceleration according to direction
            if obj.yaw_acceleration(cumulation) >= 0
                obj.yaw_acceleration(cumulation) = min(obj.max_yaw_acceleration, obj.yaw_acceleration(cumulation));
            else
                obj.yaw_acceleration(cumulation) = max(-obj.max_yaw_acceleration, obj.yaw_acceleration(cumulation));
            end
        end
            
        % ========================
        % integrate position
        % ========================
        function [obj] = integratePosition(obj, cumulation, dt)
            % distance error = position setpoint - current position
            obj.distanceerror                      = sqrt((obj.x_setpoint(cumulation)-obj.x(cumulation-1))^2+(obj.y_setpoint(cumulation)-obj.y(cumulation-1))^2);
           
            % velocity setpoint = position gain * distance error
            % limit velocity setpoint to maximum velocity
            obj.velocity_setpoint(cumulation)   = min(obj.pos_p*obj.distanceerror,obj.max_velocity);
            % constrain velocity setpoint to minimum velocity
            obj.velocity_setpoint(cumulation)   = max(obj.velocity_setpoint(cumulation), obj.min_velocity);
            % integrate velocity
            [obj]                               = integrateVelocity(obj, cumulation, dt);
            % yaw setpoint = the angle between position setpoint and current position in global coordinates
            obj.yaw_setpoint(cumulation)        = wrapTo2Pi(atan2((obj.y_setpoint(cumulation)-obj.y(cumulation-1)),obj.x_setpoint(cumulation)-obj.x(cumulation-1)));
            % integrate yaw
            [obj]                               = integrateYaw(obj, cumulation, dt);
            % integrate position
            obj.x(cumulation)                   = obj.x(cumulation-1) + obj.velocity(cumulation)*cos(obj.yaw(cumulation))*dt;
            obj.y(cumulation)                   = obj.y(cumulation-1) + obj.velocity(cumulation)*sin(obj.yaw(cumulation))*dt;
           
            %Change height aswell 
            if obj.z(cumulation-1) - obj.z_setpoint(cumulation-1) > 0.1 && obj.SPOTTED
            obj.z(cumulation) = obj.z(cumulation-1) - 1.2*obj.velocity(cumulation)*dt;
            else
            obj.z(cumulation) = obj.z(cumulation-1);
            end
              
        end
        
        % ========================
        % update uncertainty map
        % ========================
        function [obj] = updateUncertainty(obj, world, cumulation)
            % load the last global uncertainty into a temporary variable
            data                    = world.uncert_global(:,:,cumulation-1);
            
            % drive uncertainty towards nominal
            data                    = data.*world.uncert_tau + world.uncert_nom*(1-world.uncert_tau);
            
            % extract some states to make code look cleaner
            agent_x                 = obj.x(cumulation-1);
            agent_y                 = obj.y(cumulation-1);
            agent_yaw               = obj.yaw(cumulation-1);
            
            % calculate relative distance and angle between all tiles and agent
            gird_agent_dist         = euclideanDistance(agent_x,agent_y,world.grid_centre_x,world.grid_centre_y);
            grid_agent_angle        = wrapTo2Pi(atan2((world.grid_centre_y-agent_y), (world.grid_centre_x-agent_x)));
            
            % find all tiles inside the sensor radius and field of view
            intersection1           = gird_agent_dist < obj.camera_range;
            intersection2           = grid_agent_angle > wrapTo2Pi(agent_yaw-obj.camera_fov/2);
            intersection3           = grid_agent_angle < wrapTo2Pi(agent_yaw+obj.camera_fov/2);
            if (agent_yaw >= obj.camera_fov/2) && (agent_yaw <= (2*pi-obj.camera_fov/2))
                intersection_sensor = intersection1&(intersection2&intersection3);
            else
                intersection_sensor = intersection1&(intersection2|intersection3);
            end
            
            % uncertainty within sensor range become 0
            data(intersection_sensor)= 0;
            
            % update object
            obj.uncert_map(:,:,cumulation) = data;
            obj.uncert_map_sum(cumulation) = sum(sum(data));
            obj.sensor_map          = intersection_sensor;
        end
        
        % ========================
        % update probability map
        % ========================
        function [obj] = updateProbability(obj, targets, world, cumulation)
            % load the last global probability into a temporary variable
            data                    = world.prob_global(:,:,cumulation-1);
            
            % drive probability towards nominal
            data                    = data.*world.prob_tau + world.prob_nom*(1-world.prob_tau);
            
            % extract coordinates to make code look cleaner
            agent_x                 = obj.x(cumulation-1);
            agent_y                 = obj.y(cumulation-1);
            agent_yaw               = obj.yaw(cumulation-1);
            
            % initialise the detection logic map
            obj.detect_map          = false(world.number_of_tiles_y, world.number_of_tiles_x);
            obj.nodetect_map         = obj.sensor_map;
            
            for k = 1:size(targets,1)
                % this flag indicates if target is in sensor range
                target_in_sensor    = true;
                
                % extract coordinates to make code look cleaner
                target_x            = targets(k).x(cumulation-1);
                target_y            = targets(k).y(cumulation-1);
                
                % calculate distance between target and agent
                target_agent_dist   = euclideanDistance(target_x, target_y, agent_x, agent_y);
                
                % calculate angular distance between target and agent
                target_agent_yaw    = wrapTo2Pi(atan2((target_y-agent_y),(target_x-agent_x)));
                
                % if target is not in the sensor range, negate flag
                if target_agent_dist > obj.camera_range
                    target_in_sensor= false;
                end
                
                % if target is not in the sensor field of view, continue
                if target_in_sensor
                    if (agent_yaw >= obj.camera_fov/2) && (agent_yaw <= (2*pi-obj.camera_fov/2))
                        if (target_agent_yaw<wrapTo2Pi(agent_yaw-obj.camera_fov/2)) || (target_agent_yaw>wrapTo2Pi(agent_yaw+obj.camera_fov/2))
                            target_in_sensor = false;
                        end
                    else
                        if ~((target_agent_yaw>wrapTo2Pi(agent_yaw-obj.camera_fov/2)) || (target_agent_yaw<wrapTo2Pi(agent_yaw+obj.camera_fov/2)))
                            target_in_sensor = false;
                        end
                    end
                end
                
                % calculate distance between all tiles and target
                targets(k).grid_target_dist    = euclideanDistance(target_x,target_y,world.grid_centre_x,world.grid_centre_y);
                
                % find all tiles with no detection and detection
                if target_in_sensor
                    % detection = tiles around the target
                    intersection_detect     = targets(k).grid_target_dist < world.prob_range;
                    % no detection = tiles covered by the agent's sensor - tiles around the target
                    intersection_nodetect   = obj.sensor_map & (~intersection_detect);
                    
                else
                    % detection = no tiles
                    intersection_detect     = false(world.number_of_tiles_y, world.number_of_tiles_x);
                    % no detection = all tiles covered by the agent's sensor
                    intersection_nodetect   = obj.sensor_map;
                end
                
                % drive probability in the area marked as detected towards nominal
                data(intersection_detect)   = data(intersection_detect).*world.prob_detect_tau + world.prob_detect*(1-world.prob_detect_tau);
                
                % drive probability in the area marked as no detect towards nominal
                data(intersection_nodetect) = data(intersection_nodetect).*world.prob_nodetect_tau + world.prob_nodetect*(1-world.prob_detect_tau);
                
                % update agent
                obj.detect_map              = obj.detect_map | intersection_detect;
                obj.nodetect_map            = obj.nodetect_map | intersection_nodetect;
            end
            
            % update agent
            obj.prob_map(:,:,cumulation)    = data;
            obj.prob_map_sum(cumulation)    = sum(sum(data));        
        end
        
        % ========================
        % move agent
        % ========================
        function [obj] = moveAgent(obj, world, cumulation, dt, other_agents_coordinates)
            % extract coordinates to make code look cleaner
            agent_x                 = obj.x(cumulation-1);
            agent_y                 = obj.y(cumulation-1);
            
            % calculate distance between agent and grid
            grid_agent_dist         = euclideanDistance(world.grid_centre_x,world.grid_centre_y,agent_x,agent_y);
            
            % find all grids unreachable by the target using receding horizon
            unreachable_grids       = ~(grid_agent_dist < (obj.max_velocity*world.RHC_steps*dt));
            
            % calculate relative heading change between target and grid centres
            grid_agent_yaw          = wrapTo2Pi(atan2((world.grid_centre_y-agent_y),(world.grid_centre_x-agent_x)));
            
            % find optimal waypoint for agent
            if obj.type == 1
                obj                 = getFixedwingWaypoint(obj, world, unreachable_grids, grid_agent_yaw, grid_agent_dist, cumulation);
            else
                obj                 = getMultirotorWaypoint(obj, world, unreachable_grids, grid_agent_yaw, grid_agent_dist, cumulation, other_agents_coordinates);
            end
            
            % integrate
            obj                     = integratePosition(obj, cumulation, dt);
        end
        
        % ========================
        % get multirotor optimal waypoint
        % ========================
        function [obj] = getMultirotorWaypoint(obj, world, unreachable_grids, grid_agent_yaw, grid_agent_dist, cumulation, other_agents_coordinates)
            % calculate cost to reach each grid centres
            % weights
            alpha = 0.4; % probability weight
            beta = 0.1;  % distance weight
            gamma = 0.5; % heading weight
            % probability cost
            probability_cost = alpha*(1-world.prob_global(:,:,cumulation-1));
            % distance cost
            distance_cost   = beta*grid_agent_dist./world.RHC_steps/obj.max_velocity; %forgot dt
            % heading cost
            heading_difference = abs(grid_agent_yaw-obj.yaw(cumulation-1));
            heading_difference(heading_difference>=pi)=2*pi-heading_difference(heading_difference>=pi);
            heading_cost = gamma.*heading_difference./pi;
            % unreachable grids
            unreachable_cost = 10*unreachable_grids;
            % add cost around other agents
            grid_other_agent_dist = euclideanDistance(world.grid_centre_x,world.grid_centre_y,other_agents_coordinates(1),other_agents_coordinates(2));
            otheragents_grids = (grid_other_agent_dist < (130));
            otheragents_cost = 10*otheragents_grids;
            % total cost
            obj.cost = unreachable_cost + ...
                        probability_cost + ...
                        distance_cost + ...
                        heading_cost + ...
                        otheragents_cost;
                        
            % find the optimum waypoint
            [temp, waypoint_x]      = min(obj.cost);
            [~, waypoint_y]         = min(temp);
            waypoint_x              = waypoint_x(waypoint_y);
            
            % assign the optimum waypoint to the position set point
            obj.x_setpoint(cumulation) = world.grid_centre_x(waypoint_x, waypoint_y);
            obj.y_setpoint(cumulation) = world.grid_centre_y(waypoint_x, waypoint_y);
        end
        
        % ========================
        % get fixedwing optimal waypoint
        % ========================
        function [obj] = getFixedwingWaypoint(obj, world, unreachable_grids, grid_agent_yaw, grid_agent_dist, cumulation)
            % calculate cost to reach each grid centres
            alpha = 0.5; % probability weight
            beta = 0.1;  % distance weight
            gamma = 0.4; % heading weight
            % cost = yaw_change+0.7*(1-uncertainty)+0.3*(1-probability)
            % probability cost
            probability_cost = alpha*(1-world.prob_global(:,:,cumulation-1));
            % distance cost
            distance_cost   = beta*grid_agent_dist./world.RHC_steps/obj.max_velocity;
            % heading cost
            heading_difference = abs(grid_agent_yaw-obj.yaw(cumulation-1));
            heading_difference(heading_difference>=pi)=2*pi-heading_difference(heading_difference>=pi);
            heading_cost = gamma.*heading_difference./pi;
            % unreachable grids
            unreachable_cost = 10*unreachable_grids;
            % total cost
            obj.cost = unreachable_cost + ...
                        probability_cost + ...
                        distance_cost + ...
                        heading_cost;
                                  
            % find the optimum waypoint
            [temp, waypoint_x]      = min(obj.cost);
            [~, waypoint_y]         = min(temp);
            waypoint_x              = waypoint_x(waypoint_y);
            
            % assign the optimum waypoint to the position set point
            obj.x_setpoint(cumulation) = world.grid_centre_x(waypoint_x, waypoint_y);
            obj.y_setpoint(cumulation) = world.grid_centre_y(waypoint_x, waypoint_y);
        end
        
        %% private methods
        % ========================
        % expand arrays
        % ========================
        function [obj] = expandArrays(obj, ~, iter)
            obj.x(2:iter,:)             = ones(iter-1,1).*obj.x(1);
            obj.y(2:iter,:)             = ones(iter-1,1).*obj.y(1);
            obj.z(2:iter,:)             = ones(iter-1,1).*obj.z(1);
            obj.roll(2:iter,:)          = ones(iter-1,1).*obj.roll(1);
            obj.pitch(2:iter,:)         = ones(iter-1,1).*obj.pitch(1);
            obj.yaw(2:iter,:)           = ones(iter-1,1).*obj.yaw(1);
            obj.yaw_rate(2:iter,:)      = ones(iter-1,1).*obj.yaw_rate(1);
            obj.yaw_acceleration(2:iter,:) = ones(iter-1,1).*obj.yaw_acceleration(1);
            obj.velocity(2:iter,:)      = ones(iter-1,1).*obj.velocity(1);
            obj.acceleration(2:iter,:)  = ones(iter-1,1).*obj.acceleration(1);
            
            obj.assignedLandingZone             = -ones(iter-1,1);
            obj.x_setpoint(2:iter,:)            = ones(iter-1,1);
            obj.y_setpoint(2:iter,:)            = ones(iter-1,1);
            obj.z_setpoint(2:iter,:)            = ones(iter-1,1);
            obj.yaw_setpoint(2:iter,:)          = ones(iter-1,1);
            obj.yaw_rate_setpoint(2:iter,:)     = ones(iter-1,1);
            obj.yaw_acceleration_setpoint(2:iter,:) = ones(iter-1,1);
            obj.velocity_setpoint(2:iter,1)     = ones(iter-1,1);
            obj.acceleration_setpoint(2:iter,1) = ones(iter-1,1);
            
%             obj.prob_map(:,:,2:iter)    = ones(world.number_of_tiles_y, world.number_of_tiles_x, iter-1);
%             obj.prob_map_sum(2:iter)    = ones(iter-1,1);
%             obj.uncert_map(:,:,2:iter)  = ones(world.number_of_tiles_y, world.number_of_tiles_x, iter-1);
%             obj.uncert_map_sum(2:iter)  = ones(iter-1,1);
        end

        
        
        
        
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%FCFS sequencing%%%%%%%%%%%%%%%%%%%%%%%%
function [obj,vertiport] = moveAgentXYFCFS(obj, vertiport, cumulation, dt, Landing_vel)

% extract coordinates to make code look cleaner
agent_x                 = obj.x(cumulation-1);
agent_y                 = obj.y(cumulation-1);
agent_z                 = obj.z(cumulation-1);

landingPads = vertiport.occupancymat(20:end);  % Last 3 spots
thirdCircle = vertiport.occupancymat(17:19);  % Inner circle (next 3 spots)
secondCircle = vertiport.occupancymat(11:16); % Second circle (next 6 spots)

    %If in raduis and is not already spotted
    if sqrt((obj.x(cumulation-1)-vertiport.center_x)^2 + (obj.y(cumulation-1)-vertiport.center_y)^2) < 90 && ~obj.SPOTTED

    %Say the aircraft is spotted by the red diameter
    obj.SPOTTED = true;

    %Position of the drone
    POS = [agent_x,agent_y,agent_z];

    %Determine closest free point in the structure
    [obj.freeSpotIndex, obj.status] = findClosestFreeSpot(obj,vertiport.occupancymat, POS, vertiport.coordinates);

    %Set initial coordinates 
    obj.x_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,1);
    obj.y_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,2);
    obj.z_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,3);

    %Initialise previous and new locations 
    obj.xprevspot = obj.x_setpoint(cumulation);
    obj.x_new = obj.x_setpoint(cumulation);
    obj.yprevspot = obj.y_setpoint(cumulation);
    obj.y_new = obj.y_setpoint(cumulation);
    obj.zprevspot = obj.z_setpoint(cumulation);
    obj.z_new = obj.z_setpoint(cumulation);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %Set occupancy matrix for the waypoint
    vertiport = Findocc(vertiport,obj.freeSpotIndex);

    %Set the current position of the UAV
    obj.CurrentP = obj.freeSpotIndex;  

    end

    %If landing status is:
    if strcmp(obj.status, 'Landing pad available')

   
    
    %Go to new waypoint
    obj.rl = true;   
    obj.x_setpoint(cumulation) = obj.x_new;
    obj.y_setpoint(cumulation) = obj.y_new;
    obj.z_setpoint(cumulation) = obj.z_new; 
    
    %Advance on normal course
    obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
    obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
    obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);
    
    %IF close enough to waypoint
    if obj.distanceerror < vertiport.waypoint_radius

    %Set x and y and z
    obj.x(cumulation) = agent_x;
    obj.y(cumulation) = agent_y;
    if ~obj.reached 
    obj.z(cumulation-1) = obj.z_setpoint(cumulation-1);
    obj.reached = true;
    end

    %Apply landing status function
    obj = checkLandingStatus(obj,cumulation,0.5,Landing_vel,dt);            
    else  
    %Move aircraft as per FCFS
    obj = integratePosition(obj, cumulation, dt); 

    end
 

    %If landing status is:
    elseif strcmp(obj.status, 'Inner circle available')
    obj.rl = false;
    if abs(obj.y(cumulation-1) - obj.yprevspot) > 2 && abs(obj.x(cumulation-1) - obj.xprevspot) > 2 

    obj.x_setpoint(cumulation+1) = obj.xprevspot;
    obj.y_setpoint(cumulation+1) = obj.yprevspot;
    obj.z_setpoint(cumulation+1) = obj.zprevspot;
    obj = integratePosition(obj, cumulation, dt); 

    else

    obj.x_setpoint(cumulation) = obj.x_new;
    obj.y_setpoint(cumulation) = obj.y_new;
    obj.z_setpoint(cumulation) = obj.z_new;    
    %Loop for free spots
    for q = 1 : length(landingPads)         
    if landingPads(q) == 0  %If free spot

    %OLD SPOT 
    obj.xprevspot = obj.x_setpoint(cumulation);
    obj.yprevspot = obj.y_setpoint(cumulation);
    obj.zprevspot = obj.z_setpoint(cumulation);

    %Apply free spot to UAV
    obj.x_new =  vertiport.coordinates(19+q,1);
    obj.y_new =  vertiport.coordinates(19+q,2);
    obj.z_new =  vertiport.coordinates(19+q,3);

    %Add to occupancy matrix
    vertiport = Findocc(vertiport,19+q);

    %Update staus as UAV has moved
    obj.status = 'Landing pad available';

    %Remove old spot
    [vertiport] = REMocc(vertiport,obj.freeSpotIndex);

    %Update the UAVs current waypoint
    obj.freeSpotIndex = 19+q;

    %Advance on normal course
    obj.x_setpoint(cumulation) = obj.x_new;
    obj.y_setpoint(cumulation) = obj.y_new;
    obj.z_setpoint(cumulation) = obj.z_new;
    obj = integratePosition(obj, cumulation, dt); 
    end
    end

    %Advance on normal course
    obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
    obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
    obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);

    if obj.distanceerror < vertiport.waypoint_radius

    obj.x(cumulation) = obj.x(cumulation-1);
    obj.y(cumulation) = obj.y(cumulation-1);
    obj.z(cumulation) = obj.z(cumulation-1);

    else  
    obj = integratePosition(obj, cumulation, dt); 

    end
    end        
    elseif strcmp(obj.status, 'Second circle available')

    for q = 1 : length(thirdCircle)

    if thirdCircle(q) == 0 

    obj.xprevspot = obj.x_setpoint(cumulation);
    obj.yprevspot = obj.y_setpoint(cumulation);
    obj.zprevspot = obj.z_setpoint(cumulation);

    obj.x_new =  vertiport.coordinates(16+q,1);
    obj.y_new =  vertiport.coordinates(16+q,2);
    obj.z_new =  vertiport.coordinates(16+q,3);

    vertiport = Findocc(vertiport,16+q);
    obj.status = 'Inner circle available';
    [vertiport] = REMocc(vertiport,obj.freeSpotIndex);
    obj.freeSpotIndex = 16+q;

    %Advance on normal course
    obj.x_setpoint(cumulation) = obj.x_new(cumulation);
    obj.y_setpoint(cumulation) = obj.y_new(cumulation);
    obj.z_setpoint(cumulation) = obj.z_new(cumulation);
    obj = integratePosition(obj, cumulation, dt); 
    end
    end

    %Advance on normal course
    obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
    obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
    obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);

    if obj.distanceerror < vertiport.waypoint_radius

    obj.x(cumulation) = obj.x(cumulation-1);
    obj.y(cumulation) = obj.y(cumulation-1);
    obj.z(cumulation) = obj.z(cumulation-1);

    else  
    obj = integratePosition(obj, cumulation, dt); 

    end



    elseif strcmp(obj.status, 'Outer circle available')

    for q = 1 : length(secondCircle)

    if secondCircle(q) == 0 


    obj.x_setpoint(cumulation) =  vertiport.coordinates(10+q,1);
    obj.y_setpoint(cumulation) =  vertiport.coordinates(10+q,2);
    obj.z_setpoint(cumulation) =  vertiport.coordinates(10+q,3);


    vertiport = Findocc(vertiport,10+q);
    obj.status = 'Second circle available';
    [vertiport] = REMocc(vertiport,obj.freeSpotIndex);
    obj.freeSpotIndex = 10+q;

    %Advance on normal course
    obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
    obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
    obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);
    obj = integratePosition(obj, cumulation, dt); 
    end

    end


        %Advance on normal course
        obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
        obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
        obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);

        if obj.distanceerror < vertiport.waypoint_radius

        obj.x(cumulation) = obj.x(cumulation-1);
        obj.y(cumulation) = obj.y(cumulation-1);
        obj.z(cumulation) = obj.z(cumulation-1);

        else  
        obj = integratePosition(obj, cumulation, dt); 

        end

        else
        %Advance on normal course
        obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
        obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
        obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);


        obj = integratePosition(obj, cumulation, dt); 
        end


        if obj.SPOTTED

            if obj.x(cumulation) == obj.x(cumulation-1)

            obj.Holdtime = obj.Holdtime + dt;
            else
            obj.Movetime = obj.Movetime + dt;
            end
        end        
end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %OM Sequencing method
      function [obj,vertiport] = moveAgentXYOM(obj, vertiport, cumulation, dt, Landing_vel)
           
            % extract coordinates to make code look cleaner
            agent_x                 = obj.x(cumulation-1);
            agent_y                 = obj.y(cumulation-1);
            agent_z                 = obj.x(cumulation-1);
            UAV_positions           = [agent_x agent_y];
            DONTMOVE = 0;
            
            if obj.assignedLandingZone(cumulation-1) > 0
                DONTMOVE = 0;
            end
            
            % Loop through each waypoint and extract the coordinates
            for k = 1:numel(vertiport.waypoints)
                landingZones(k, :) = vertiport.waypoints{k}; % Extract x, y from each cell
            end
            
if sqrt((obj.x(cumulation-1)-vertiport.center_x)^2 + (obj.y(cumulation-1)-vertiport.center_y)^2) < 90
            [vertiport,obj] = greedyMethod(obj,vertiport,UAV_positions, landingZones,vertiport.AZones,cumulation);
            
            if obj.assignedLandingZone(cumulation) ~= obj.assignedLandingZone(cumulation-1) && obj.assignedLandingZone(cumulation-1) ~= -1
                
                 [vertiport] = az(vertiport, obj.assignedLandingZone(cumulation-1));
            end
end

if sqrt((obj.x(cumulation-1)-vertiport.center_x)^2 + (obj.y(cumulation-1)-vertiport.center_y)^2) < 40
     
     if obj.assignedLandingZone(cumulation) < 0
         
     DONTMOVE = 1;
     end
     
 end  
 
 
            if obj.assignedLandingZone(cumulation) > 0
            obj.x_setpoint(cumulation) = landingZones(obj.assignedLandingZone(cumulation), 1);
            obj.y_setpoint(cumulation) = landingZones(obj.assignedLandingZone(cumulation), 2);
            end
     
            %Advance on normal course
            obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
            obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
            obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);
            
          
      if obj.distanceerror < vertiport.waypoint_radius
             
                obj.x(cumulation) = agent_x;
                obj.y(cumulation) = agent_y;

                
             obj = checkLandingStatus(obj,cumulation,0.5,Landing_vel,dt);
                    
                
                
      else
          if DONTMOVE ~= 1
                 obj = integratePosition(obj, cumulation, dt); 
          else
               obj.x(cumulation) = obj.x(cumulation-1);
               obj.y(cumulation) = obj.y(cumulation-1);

          end
      end
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
          function [vertiport,obj] = greedyMethod(obj,vertiport,UAV_positions, landingZones, availableZones,cumulation)
 
    numZones = size(landingZones, 1);
    
   
        minDistance = inf; % Start with a very large distance
        selectedZone = -1; % Placeholder for the selected landing zone
        
        % Compare distance to each available landing zone
        for j = 1:numZones
            if availableZones(j) == 1 || obj.assignedLandingZone(cumulation-1) == j % Only check available zones
                % Calculate Euclidean distance
                dist = sqrt((UAV_positions(1) - landingZones(j, 1))^2 + (UAV_positions(2) - landingZones(j, 2))^2);
                
                % If this is the closest zone so far, select it
                if dist < minDistance
                    minDistance = dist;
                    selectedZone = j;
                end
            end
        end
        
        % If a zone is found, assign it to the UAV
        if selectedZone ~= -1
            obj.assignedLandingZone(cumulation) = selectedZone;
            availableZones(selectedZone) = 0; % Mark the zone as taken
        else
            % If no zone is available, leave this UAV unassigned (optional)
            obj.assignedLandingZone(cumulation) = -1;
        end
  

    % Output updated available zones
    vertiport.AZones = availableZones;
  
          end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
         

if sqrt((obj.x(cumulation-1)-vertiport.center_x)^2 + (obj.y(cumulation-1)-vertiport.center_y)^2) < 90 
        

                 if obj.x(cumulation) == obj.x(cumulation-1) 


                            obj.Holdtime = obj.Holdtime + dt;
                 else
                            obj.Movetime = obj.Movetime + dt;
                 end

end
             

        end
             
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     function [obj,vertiport,Bestp] = moveAgentXYAQM(obj, vertiport, cumulation, dt, Landing_vel,otheragentc,plc)
      
            % extract coordinates to make code look cleaner
            agent_x                 = obj.x(cumulation-1);
            agent_y                 = obj.y(cumulation-1);
            agent_z                 = obj.z(cumulation-1);
  
  
    if sqrt((obj.x(cumulation-1)-vertiport.center_x)^2 + (obj.y(cumulation-1)-vertiport.center_y)^2) < 90 && ~obj.SPOTTED
        
        %Say the aircraft is spotted by the red diameter
        obj.SPOTTED = true;
        
         %Position of the drone
        POS = [agent_x,agent_y,agent_z];
        
        %Determine closest free point in the structure
        [obj.freeSpotIndex, ~] = findClosestFreeSpot(obj,vertiport.occupancymat, POS, vertiport.coordinates);
        
          obj.x_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,1);
          obj.y_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,2);
          obj.z_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,3);

  
          
    if obj.SPOTTED
     
    % Determine the depth (which semi-circle) the entryPoint is on
   depth = findEntryDepth(obj,obj.freeSpotIndex, vertiport.pointsPerSemiCircle);
   
   if depth > 0 
   vertiport.allPaths = [];
   [vertiport] = explorePaths(vertiport,obj.freeSpotIndex, obj.freeSpotIndex, depth,vertiport.pointsPerSemiCircle,vertiport.landingPads, vertiport.hoverHeight,vertiport.nSemiCircles);
   obj.allPaths = vertiport.allPaths; %Find all paths that the UAV can take from that holding spot
   
    %Best possilbe path for the given information 
    [assignedPaths,rewards] = assignPriority(obj,obj.allPaths, vertiport.coordinates,[1:sum(vertiport.pointsPerSemiCircle)+size(vertiport.landing_spots,1)], vertiport.occupancymat,vertiport,otheragentc);
    
    if max(rewards) < 50 
       
    [~,ind] = max(rewards);
    
    BestP = obj.allPaths(ind);
    
    end
       
    %Current path taken by UAV 
    obj.CurrentP = assignedPaths;
    
      for k = 1 : length(obj.CurrentP) - 1
        
      vertiport = Findocc(vertiport,obj.CurrentP(k));
      
      obj.LocalQUE(k) = vertiport.occupancymat(obj.CurrentP(k));
      obj.QN = 1;
      end
      
     
   else
       
   vertiport = Findocc(vertiport,obj.freeSpotIndex);
   obj.LocalQUE = vertiport.occupancymat(obj.freeSpotIndex);     
   obj.CurrentP = obj.freeSpotIndex;  
   obj.QN = 1;
 
   end
   
    end   
    end
    
    Bestp = [-1,-1,-1];
    
     if obj.COOP
       obj.COOP = false;
    % Determine the depth (which semi-circle) the entryPoint is on
   depth = findEntryDepth(obj,obj.freeSpotIndex, vertiport.pointsPerSemiCircle);
   
   if depth > 0 
   vertiport.allPaths = [];
   [vertiport] = explorePaths(vertiport,obj.freeSpotIndex, obj.freeSpotIndex, depth,vertiport.pointsPerSemiCircle,vertiport.landingPads, vertiport.hoverHeight,vertiport.nSemiCircles);
   obj.allPaths = vertiport.allPaths; %Find all paths that the UAV can take from that holding spot
   
    %Best possilbe path for the given information 
    [assignedPaths,rewards] = assignPriority(obj,obj.allPaths, vertiport.coordinates,[1:sum(vertiport.pointsPerSemiCircle)+size(vertiport.landing_spots,1)], vertiport.occupancymat,vertiport,otheragentc);
    
    if max(rewards) < 80
       
    [~,ind] = max(rewards);
    
    BestP = obj.allPaths(ind);
    
      if vertiport.occupancymatrix(obj.freeSpotIndex - 1) == 0
      obj.freeSpotIndex = obj.freeSpotIndex-1;
      vertiport = Findocc(vertiport, obj.freeSpotIndex);
      end
          obj.x_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,1);
          obj.y_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,2);
          obj.z_setpoint(cumulation) =  vertiport.coordinates(obj.freeSpotIndex,3);

   vertiport.allPaths = [];
   [vertiport] = explorePaths(vertiport,obj.freeSpotIndex, obj.freeSpotIndex, depth,vertiport.pointsPerSemiCircle,vertiport.landingPads, vertiport.hoverHeight,vertiport.nSemiCircles);
   obj.allPaths = vertiport.allPaths; %Find all paths that the UAV can take from that holding spot
   
    %Best possilbe path for the given information 
    [assignedPaths,~] = assignPriority(obj,obj.allPaths, vertiport.coordinates,[1:sum(vertiport.pointsPerSemiCircle)+size(vertiport.landing_spots,1)], vertiport.occupancymat);
    
    end
       
    %Current path taken by UAV 
    obj.CurrentP = assignedPaths;
    
      for k = 1 : length(obj.CurrentP) - 1
        
      vertiport = Findocc(vertiport,obj.CurrentP(k));
      
      obj.LocalQUE(k) = vertiport.occupancymat(obj.CurrentP(k));
      obj.QN = 1;
      end
   end
     end
     
     
     
     
            %Advance on normal course
            obj.x_setpoint(cumulation+1) = obj.x_setpoint(cumulation);
            obj.y_setpoint(cumulation+1) = obj.y_setpoint(cumulation);
            obj.z_setpoint(cumulation+1) = obj.z_setpoint(cumulation);
            
           

            if obj.distanceerror < vertiport.waypoint_radius
             
                obj.x(cumulation) = agent_x;
                obj.y(cumulation) = agent_y;
                
                if ~obj.reached 
                obj.z(cumulation-1) = obj.z_setpoint(cumulation-1);
                obj.reached = true;
                end
                
                obj.index = find(obj.CurrentP == obj.freeSpotIndex);
          
                % Determine the depth (which semi-circle) the entryPoint is on
                depth = findEntryDepth(obj,obj.freeSpotIndex, vertiport.pointsPerSemiCircle);
   
          if depth > 0
          obj.reached = false;
         
          obj.remove =  obj.freeSpotIndex;
          obj.freeSpotIndex = obj.CurrentP(obj.index+1);
          obj.x_setpoint(cumulation) =  vertiport.coordinates(obj.CurrentP(obj.index+1),1);
          obj.y_setpoint(cumulation) =  vertiport.coordinates(obj.CurrentP(obj.index+1),2);
          obj.z_setpoint(cumulation) =  vertiport.coordinates(obj.CurrentP(obj.index+1),3);
          obj.x_setpoint(cumulation+1) =  obj.x_setpoint(cumulation);
          obj.y_setpoint(cumulation+1) =  obj.y_setpoint(cumulation);
          obj.z_setpoint(cumulation+1) =  obj.z_setpoint(cumulation);
          obj = integratePosition(obj, cumulation, dt);
          
            
          %Save previous nodal waypoint for queue removal
          xwaypointqueue =  vertiport.coordinates(obj.CurrentP(obj.index),1);
          ywaypointqueue =  vertiport.coordinates(obj.CurrentP(obj.index),2);
          zwaypointqueue =  vertiport.coordinates(obj.CurrentP(obj.index),3);
          obj.PreviousQueueLocation = norm([xwaypointqueue,ywaypointqueue,zwaypointqueue]);
          
          obj.QN = obj.QN + 1;
           
     
          else
              
             
              obj = checkLandingStatus(obj,cumulation,0.5,Landing_vel,dt);
                
          end
 
            else
                
            % integrate
               if obj.freeSpotIndex == 0
                 obj = integratePosition(obj, cumulation, dt); 
               elseif obj.LocalQUE(obj.QN) < 2
                obj = integratePosition(obj, cumulation, dt);
               else
               obj.x(cumulation)                = obj.x(cumulation-1);
               obj.y(cumulation)                = obj.y(cumulation-1);
               obj.z(cumulation)                = obj.z(cumulation-1);  
               end  
            end
            

              if obj.SPOTTED

                 if obj.x(cumulation) == obj.x(cumulation-1)   


                            obj.Holdtime = obj.Holdtime + dt;
                 else
                            obj.Movetime = obj.Movetime + dt;
                 end


               end

     end
       
 
        
function [closestSpotIndex, status] = findClosestFreeSpot(~,occupancyMatrix, dronePosition, positionMatrix)
    % Inputs:
    % occupancyMatrix: 1x22 array (1 = occupied, 0 = free)
    % dronePosition: 1x3 array representing the current [x, y, z] position of the drone
    % positionMatrix: 22x3 matrix where each row is the [x, y, z] coordinates of the spots
    
    % Define the sections in the occupancy matrix
    landingPads = occupancyMatrix(20:end);  % Last 3 spots
    thirdCircle = occupancyMatrix(17:19);  % Inner circle (next 3 spots)
    secondCircle = occupancyMatrix(11:16); % Second circle (next 6 spots)
    outerCircle = occupancyMatrix(1:10);   % Outer circle (first 10 spots)
    
    % Initialize variables to hold the index of the closest free spot and the minimum distance
    closestSpotIndex = [];
    minDistance = inf;  % Start with infinity
    
    % Function to calculate Euclidean distance
    function dist = calcDistance(pos1, pos2)
        dist = sqrt(sum((pos1 - pos2).^2));
    end
    
    % Check landing pads first
    freeIndices = find(landingPads == 0);  % Find the indices of free landing pads
    if ~isempty(freeIndices)
        for i = 1:length(freeIndices)
            spotIndex = freeIndices(i) + 19;  % Adjust index to match the original matrix (for landing pads)
            distance = calcDistance(dronePosition, positionMatrix(spotIndex, :));
            if distance < minDistance
                minDistance = distance;
                closestSpotIndex = spotIndex;
            end
        end
        status = 'Landing pad available';
        return;
    end
    
    % If no landing pads are free, check the third circle
    freeIndices = find(thirdCircle == 0);  % Find the indices of free inner circle spots
    if ~isempty(freeIndices)
        for i = 1:length(freeIndices)
            spotIndex = freeIndices(i) + 16;  % Adjust index to match the original matrix (for inner circle)
            distance = calcDistance(dronePosition, positionMatrix(spotIndex, :));
            if distance < minDistance
                minDistance = distance;
                closestSpotIndex = spotIndex;
            end
        end
        status = 'Inner circle available';
        return;
    end
    
    % If no inner circle spots are free, check the second circle
    freeIndices = find(secondCircle == 0);  % Find the indices of free second circle spots
    if ~isempty(freeIndices)
        for i = 1:length(freeIndices)
            spotIndex = freeIndices(i) + 10;  % Adjust index to match the original matrix (for second circle)
            distance = calcDistance(dronePosition, positionMatrix(spotIndex, :));
            if distance < minDistance
                minDistance = distance;
                closestSpotIndex = spotIndex;
            end
        end
        status = 'Second circle available';
        return;
    end
    
    % If no second circle spots are free, check the outer circle
    freeIndices = find(outerCircle == 0);  % Find the indices of free outer circle spots
    if ~isempty(freeIndices)
        for i = 1:length(freeIndices)
            spotIndex = freeIndices(i);  % No adjustment needed for outer circle
            distance = calcDistance(dronePosition, positionMatrix(spotIndex, :));
            if distance < minDistance
                minDistance = distance;
                closestSpotIndex = spotIndex;
            end
        end
        status = 'Outer circle available';
        return;
    end
    
    % If no spots are available, return a status message
    closestSpotIndex = [];  % No free spot
    status = 'No free spots available';
end

  
        
 % Assign paths with priority based on multiple criteria
function [assignedPaths, rewards] = assignPriority(~,allPaths, coordinates, holdingSpots, occupancyMatrix,vertiport,otheragentc)

    nPaths = length(allPaths);  % Number of possible paths
    rewards = zeros(1, nPaths);  % Initialize reward array
    
    for i = 1:nPaths
        path = allPaths{i};  % Current path
        
        % Extract the last point (which should be the landing pad)
        finalPoint = path(end);
        
        % 1. Calculate distance-based reward (higher reward for shorter distance)
        pathLength = calculatePathLength(path, coordinates);
        distanceReward = 1 / pathLength*100;  % Inverse of length, shorter paths get higher reward
           
        % 2. Calculate traffic penalty for holding spots
        trafficPenalty = calculateTrafficPenalty(path, holdingSpots, occupancyMatrix,vertiport,otheragentc);
        
        % Calculate the final reward for this path
        rewards(i) = 100 -(distanceReward + trafficPenalty);
    end
    
    % 3. Randomized urgency penalty (lower urgency gets higher penalty)
        urgencyPenalty = calculateUrgencyPenalty();
        
        rewards = rewards - urgencyPenalty;
        
    % Find the path with the highest reward
    [~, bestPathIndex] = max(rewards);
    
    % Assign the path with the highest reward
    assignedPaths = allPaths{bestPathIndex};
   
    
    
    % Helper function to calculate path length (Euclidean distance)
function pathLength = calculatePathLength(path, coordinates)
    pathLength = 0;
    for j = 1:length(path)-1
        % Euclidean distance between consecutive points
        pathLength = pathLength + norm(coordinates(path(j+1), :) - coordinates(path(j), :));
    end
end


% Helper function to calculate traffic penalty based on holding spot congestion
    function penalty = calculateTrafficPenalty(path, holdingSpots, occupancyMatrix,vertiport,otheragentc)
    penalty = 0;
    
    for j = 1:length(path)
        point = path(j);
        
        % Check if the point is a holding spot
        holdingSpotIndex = find(holdingSpots == point, 1);
        
        if ~isempty(holdingSpotIndex)
            % Look up whether the holding spot is occupied (1 means occupied, 0 means free)
            if occupancyMatrix(holdingSpotIndex) >= 1
                % Apply a penalty if the holding spot is occupied
                penalty = penalty + occupancyMatrix(holdingSpotIndex)*5;  % Fixed penalty for congestion (can be adjusted)

                %Calculate penalty due to time delay on the point itself
                for k = 1 : size(otheragentc,2)
                    if otheragentc(7,k) == holdingSpotIndex

                        distaway = sqrt((otheragentc(1,k) - vertiport.coordinates(holdingSpotIndex,1))^2 + ...
                            (otheragentc(2,k) - vertiport.coordinates(holdingSpotIndex,2))^2);

                        penalty = penalty + 0.2*distaway;

                    end
                end
            end
        end
    end
end

% Helper function to add a randomized urgency penalty
function urgencyPenalty = calculateUrgencyPenalty()
    % Random urgency factor (can be adjusted based on a specific range)
    urgencyLevel = rand();  % Random value between 0 and 1
    
    % Lower urgencyLevel (closer to 0) means higher urgency, so less penalty
    urgencyPenalty = 30 * (1 - urgencyLevel);  % Penalty decreases with higher urgency
end
end

% Helper function to find the depth of the entry point
function depth = findEntryDepth(~,entryPoint, pointsPerSemiCircle)
    depth = 0;
    cumulativePoints = cumsum(pointsPerSemiCircle);
    depth = find(cumulativePoints >= entryPoint, 1);
end

        
        
        function obj = checkLandingStatus(obj,cumulation, threshold,Landing_vel,dt)
  
                if obj.z(cumulation-1) > threshold
                    
                %Complete landing sequence 
                obj.z(cumulation) = obj.z(cumulation-1) - Landing_vel*dt;

                else 
                           obj.z(cumulation) = obj.z(cumulation-1);
                           obj.hasLanded = true;
                           
                end
        end
    end
end


function obj = coop(obj,vertiport, Bestpath)

  if obj.freeSpotIndex == Bestpath(1)
                    if vertiport.occupancymatrix(BestPath(1) - 1) == 0
                       obj.freeSpotIndex = BestPath(1) - 1;
                       vertiport = Findocc(vertiport, BestPath(1) - 1);
                       [vertiport] = REMocc(vertiport,obj.freeSpotIndex);

                    end

                  obj.x_setpoint(cumulation) =  vertiport.coordinates(BestPath(1) - 1,1);
                  obj.y_setpoint(cumulation) =  vertiport.coordinates(BestPath(1) - 1,2);
                  obj.z_setpoint(cumulation) =  vertiport.coordinates(BestPath(1) - 1,3);
                   
                  
                  obj.COOP = true;
                  
  end
end