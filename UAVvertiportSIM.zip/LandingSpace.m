classdef LandingSpace
    properties
        Radius      % Radius of the circle
        HHeight     % Height of the H
        HWidth      % Width of the H
        LineWidth   % Width of the lines for the circle and H
    end
    
    methods
        % Constructor method to initialize properties
        function obj = LandingSpace(radius, h_height, h_width, line_width)
            if nargin > 0
                obj.Radius = radius;
                obj.HHeight = h_height;
                obj.HWidth = h_width;
                obj.LineWidth = line_width;
            else
                obj.Radius = 5;
                obj.HHeight = 4;
                obj.HWidth = 2;
                obj.LineWidth = 10; % Make the lines bolder
            end
        end
        
        % Method to plot the landing space
        function plotLandingSpace(obj)
            figure;
            hold on;
            
            % Plot and fill the circle in yellow
            theta = linspace(0, 2*pi, 100);
            x_circle = obj.Radius * cos(theta);
            y_circle = obj.Radius * sin(theta);
            fill(x_circle, y_circle, 'yellow'); % Fill the circle with yellow
            plot(x_circle, y_circle, 'b', 'LineWidth', obj.LineWidth); % Outline in blue
            
            % Plot the H (with the yellow background inside the circle)
            % Vertical bars of the H
            plot([-obj.HWidth/2, -obj.HWidth/2], [-obj.HHeight/2, obj.HHeight/2], 'b', 'LineWidth', obj.LineWidth);
            plot([obj.HWidth/2, obj.HWidth/2], [-obj.HHeight/2, obj.HHeight/2], 'b', 'LineWidth', obj.LineWidth);
            
            % Middle bar of the H
            plot([-obj.HWidth/2, obj.HWidth/2], [0, 0], 'b', 'LineWidth', obj.LineWidth);
            
            % Set the axes limits
            axis equal;
            xlim([-obj.Radius-1, obj.Radius+1]);
            ylim([-obj.Radius-1, obj.Radius+1]);
            
            % Set the axes labels and title
            xlabel('X-axis');
            ylabel('Y-axis');
            title('2D Landing Space with H and Circle');
            
            % Turn on the grid
            grid on;
            hold off;
        end
    end
end


