%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Vertiport Simulation 
%AQM, FCFS, OM sequencing algorithms 
%Created by Aaron Koulouris 
%Last Edited : 1/11/2024
clc; clear; close all;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Experimental Loops
% for LZ = 1 : 4   
%     if LZ == 1
%         landing_zone = [10,30];   
%     elseif LZ == 2
%         landing_zone = [10,20;10,40];
%     elseif LZ == 3
%         landing_zone = [10,10;10,30;10,50];
%     else
%         landing_zone = [10,9;10,23;10,37;10,51];
%     end
% for Tt = 1 : 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Main script to create and animate waypoints
%%%%%%%%%%%BUILD THE ENVIRONMENT%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create an instance of the LandingSpace class
landing_space = LandingSpace(5, 4, 2, 2);
landing_zone = [10,9;10,23;10,37;10,51];
% Create an instance of the VertiportWorld class
vertiport = VertiportWorld(0,60, 60, 90, landing_space, 200,0,0,landing_zone);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Landing Zone results (utilization)
LandingZ = zeros(size(vertiport.landingPads,1),1);

% %Loading in UAV positions 
% load('RGA.mat');

% Set animation parameters
animation_speed = 0.01; % Speed of waypoint movement (smaller value = slower)
rotation_speed = 0.1; % Speed of rotation around the circle
rotation_angle = 0; % Initial rotation angle
aircraft_scale      = 5;
multirotor_scale    = 14;
target_scale        = 90;
color_pallete       = ['r';'y';'k';'m'];
color_pallete_agent = ['g';'r';'m'];

% Set up 3D view
view(3); % Switch to 3D view
set(gca,'FontName', 'Times New Roman','FontSize',14)                
xlabel("Meters (m)",'FontSize', 14,'FontName', 'Times New Roman');
ylabel("Meters (m)",'FontSize', 14,'FontName', 'Times New Roman');
zlabel("Meters (m)",'FontSize', 14,'FontName', 'Times New Roman');               
grid on;
axis([45 155 45 155 0 55]);

% start simulation
t_init              = 0;
t                   = t_init; % seconds
dt                  = 1; % seconds
t_total             = 1000;
cumulation          = 1;
iterations          = ceil(t_total/dt)+1;

%Simulation Paramters
Land_vel = 0.28;          %Landing velocity
BestPath = [-1,-1,-1];    %Initialise best path array 
otheragentc = zeros(7,1); %Initialise other agents array
b = 0;                    %Initialise UAV counting number 
% count = 1;              %Initialise count

% skip initial condition before the loop starts
cumulation          = cumulation+1;
t                   = t+dt;
iterationcount      = 1;


%agent Initialisation
agent = []; %UAVs
tplot = []; %time plotting
QL = [];    %Queue length 
AGENT = []; %Move and Hold array
AGENTC = 0; %Move and Hold array counter;

% Define the center of the map 
mapCenterX = vertiport.outer_square_size / 2;
mapCenterY = vertiport.outer_square_size / 2;

% Animation loop
while cumulation < 1001 % Continue if the figure window is open

    % Increment the iteration counter
    iterationcount = iterationcount + 1;

    %Add to time array
    tplot(iterationcount) = t;

    %Check to see if any aircraft have landed
    for ld = 1 : length(agent)
        
        %Check if the aircraft has landed
        if agent(ld).hasLanded
            
            %Delete aircraft if it has and remove from occupancy matrix
            delete(agent(ld).figure_handle_debug);
            delete(agent(j).figure_handle_waypoint);
            [vertiport] = REMocc(vertiport,agent(ld).freeSpotIndex); %Removing function.

%             %%%%%%%%%%%%%%%%%%%%%%%%%%%CHANGE IF USING AQM%%%%%%%%%%%%%%%
%             %Update local queues as a free spot has come up 
%             for id = 1 : length(agent)
%                for lq = 1 : length(agent(id).CurrentP)-1
%                    if agent(id).CurrentP(lq) == agent(ld).freeSpotIndex
%                        
%                        %Change local queues for UAVS
%                        agent(id).LocalQUE(lq) = agent(id).LocalQUE(lq) - 1;
%                    end
%                end
%             end    
%             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
            %Record move time and hold time 
            AGENTC = AGENTC + 1; 
            AGENT(AGENTC,2) = agent(ld).Movetime;
            AGENT(AGENTC,1) = agent(ld).Holdtime;
            
            %Remove agent from list to speed up simulation
            agent(ld) = [];

         break
        end

    end
    
%%%%%%%%%%%%%%Dont add unless running AQM%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Check to see if any aircraft have reached there ho,ding points
%     for ld = 1 : length(agent)
% 
%        %Remove from holding point in occupancy matrix
%        if agent(ld).remove > 0
%             if abs(vertiport.coordinates(agent(ld).remove,2) - agent(ld).y(cumulation-1)) > 3
%                 [vertiport] = REMocc(vertiport,agent(ld).remove); %Remove function
%                
%              
%             for id = 1 : length(agent)
%                for lq = 1 : length(agent(id).CurrentP)-1
%                    if agent(id).CurrentP(lq) == agent(ld).remove
%                         %Change local queues for UAVS
%                        agent(id).LocalQUE(lq) = agent(id).LocalQUE(lq) - 1;
%                    end
%                end
%             end
%             
%               %Set the UAVs remove paramter to zero as its successfully
%               %heading to its next holding point
%               agent(ld).remove = 0;
%             end
%             
%            
%                 
%        end
%        
% 
%     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  


% ADD NEW AIRCRAFT (RANDOM LOCATION) 
if mod(iterationcount, 60) == 0 && length(agent) < 21 %Every X seconds add in a UAV
    
     %If UAV has reached maximum allowed in airspace
     if length(agent) > 19
        cumulation = 10000;
        disp('Fail')
     end
     
    % Generate random x and y coordinates
    x = rand * 90;
    y = randi([0, 1]) * 200;
    
    % Calculate the angle to the center of the map
    angleToCenter = atan2(mapCenterY - y, mapCenterX - x);
    
    %Add to UAV counter
    b = b + 1;
    
%     %Save UAV positions for plotting
%     RGA(b,:) = [x, y, angleToCenter];
%     x = RGA(DRONE,1);
%     y = RGA(DRONE,2);
%     angleToCenter = RGA(DRONE,3);
%     DRONE = DRONE + 1;
   

    % Create a new Aircraft object
    newAircraft = Aircraft(2, x, y, 80, 0, 0, angleToCenter, 1, 1.4, 0, deg2rad(90));
    newAircraft = expandArrays(newAircraft, vertiport, iterations);
    
    %Send to holding position 1
    newAircraft.x_setpoint(cumulation) = vertiport.center_x;
    newAircraft.y_setpoint(cumulation) = vertiport.center_y;
    newAircraft.z_setpoint(cumulation) =  20;
    
    % Append the new aircraft to the agent array
    agent = [agent, newAircraft];
    
end

     %Control agents to land simulate aircraft moving to required landing
     %zone
     if cumulation < 1001
     for i = 1:length(agent)  
         
%          %If moveAgent function has detected a better path due to low
%          %reward
%          if BestPath(1) > 0
%             for i = 1:length(agent)
%              %Coop UAV function to alter waypoints 
%              coop(agent(i),vertiport, Bestpath)
%             end
%          end
     
                %Keep track of all UAVs positions and headings
                otheragentc(:,i) = [agent(i).x(cumulation-1), agent(i).y(cumulation-1), agent(i).z(cumulation-1),agent(i).x_setpoint(cumulation-1), agent(i).y_setpoint(cumulation-1), agent(i).z_setpoint(cumulation-1)...
                agent(i).freeSpotIndex];
             
              %Move agents using sequencing 
%             [agent(i),vertiport,Bestpath] = moveAgentXYAQM(agent(i),vertiport, cumulation, dt,Land_vel,otheragentc,i);
            [agent(i),vertiport] = moveAgentXYFCFS(agent(i),vertiport, cumulation, dt,Land_vel);
%             [agent(i),vertiport] = moveAgentXYOM(agent(i),vertiport, cumulation, dt,Land_vel);
         
     end % end agent loop
   
     %PLotting 
    for j = 1:length(agent)
        
         hold on
         figure(1)
                delete(agent(j).figure_handle_debug);
               
                agent(j).figure_handle_debug = quadrotor(agent(j).x(cumulation), agent(j).y(cumulation), agent(j).z(cumulation),...
                         'roll', rad2deg(agent(j).roll(cumulation)), 'pitch', rad2deg(agent(j).pitch(cumulation)),...
                         'yaw', rad2deg(agent(j).yaw(cumulation)), 'scale', multirotor_scale, 'body', color_pallete_agent(1),...
                         'boom', color_pallete_agent(1), 'prop', color_pallete_agent(1), 'linestyle', 'none');
   
                     
                delete(agent(j).figure_handle_waypoint);

                %Only plot waypoint if UAV is in the circle
               
                if sqrt((agent(j).x(cumulation-1)-vertiport.center_x)^2 + (agent(j).y(cumulation-1)-vertiport.center_y)^2) < 90
                agent(j).figure_handle_waypoint = plot3(agent(j).x_setpoint(cumulation), agent(j).y_setpoint(cumulation), agent(j).z_setpoint(cumulation), ...
                        'o', 'markersize', 10, 'color', color_pallete_agent(1),'linewidth',3);

                end

%Experimental utilisaation rates 
%                   %Dertmine vertiport utilizations
%                   if abs(agent(j).x(cumulation-1) - vertiport.landingPads(1,1)) < 5 
%                     for d = 1 : size(vertiport.landingPads,1)
%                         if abs(agent(j).y(cumulation-1) - vertiport.landingPads(d,2)) < 5
%                             %LandingZ represents utilisation
%                             LandingZ(d,iterationcount) = 1*vertiport.occupancymat(19+d);
%                             break;                 
%                         end
%                     end      
%                   end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     end
     
%      %Find maximum queue length for research
%      count = sum(vertiport.occupancymat(1:19) > 0);
%      QL(iterationcount) = sum(count);
     
     %Make sure sizes are consistant for plotting
     if size(LandingZ,2) ~= length(tplot)    
         LandingZ(:,iterationcount) = 0;
     end
     
    % Ensure the figure updates smoothly
    drawnow;  
    % Pause to control animation speed
    pause(animation_speed);


    % increment time step
    t               = t + dt;
    cumulation      = cumulation + 1;
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% close all
% %          %Move            Hold            Throughput
% AVERAGE(Tt,:) = [mean(AGENT(:,1)) mean(AGENT(:,2)) length(AGENT)];
% 
% 
% end
% close all
% AFINAL(LZ,:) = [mean(AVERAGE(:,1)) mean(AVERAGE(:,2)) mean(AVERAGE(:,3))];
% 
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
